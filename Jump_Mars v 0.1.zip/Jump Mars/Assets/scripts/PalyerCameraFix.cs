﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PalyerCameraFix : MonoBehaviour {

    public GameObject PlayerObject;
	
	// Update is called once per frame
	void Update () {
		if(PlayerObject != null)
        {
            transform.position = new Vector3(PlayerObject.transform.position.x, PlayerObject.transform.position.y,
                transform.position.z);
        }
	}
}
