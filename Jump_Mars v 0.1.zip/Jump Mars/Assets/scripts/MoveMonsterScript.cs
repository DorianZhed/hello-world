﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveMonsterScript : MonoBehaviour {

    public Vector2 speed = new Vector2(3, 0);
    public Vector2 direction = new Vector2(1, 0);

    public float originX;
    public float originY;

    private Vector2 movement;
    private Rigidbody2D rigidbodyComponent;

	
	// Update is called once per frame
	void Update () {
        movement = new Vector2(speed.x * direction.x, speed.y * direction.y);

        originX = transform.position.x - GetComponent<BoxCollider2D>().offset.x + (GetComponent<BoxCollider2D>().size.x * direction.x);
        originY = transform.position.y - GetComponent<BoxCollider2D>().offset.y /*- GetComponent<BoxCollider2D>().size.y*/;

        RaycastHit2D rayhit = Physics2D.Raycast(new Vector2(originX, originY), Vector2.down, 1.0f);
        if (rayhit.collider == null)
        {
            direction.x = -direction.x;
            //changeDirection();
        }
    }

    void FixedUpdate()
    {
        GetComponent<Rigidbody2D>().velocity = movement;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Wall") || collision.gameObject.CompareTag("Ennemi"))
        {
            direction.x = -direction.x;
            //changeDirection();
        }
    }

    void changeDirection()
    {
        direction.x = -direction.x;
        transform.rotation = Quaternion.AngleAxis(180, transform.up);
    }
}
