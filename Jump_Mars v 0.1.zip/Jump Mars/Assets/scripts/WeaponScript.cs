﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponScript : MonoBehaviour
{

    public Transform shotPrefab;
    public float shootingRate = 0.1f;
    private float shootCooldown;

    // Use this for initialization
    void Start()
    {
        shootCooldown = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (shootCooldown > 0)
        {
            shootCooldown -= Time.deltaTime;
        }
    }

    public void Attack()
    {
        if (CanAttack)
        {
            shootCooldown = shootingRate;

            var shotTransform = Instantiate(shotPrefab) as Transform;

            Vector3 positionBullet = transform.position;
            positionBullet.y = positionBullet.y - (float)0.15;

            shotTransform.position = positionBullet;

            MoveScript move = shotTransform.gameObject.GetComponent<MoveScript>();
            if (move != null) move.direction = this.transform.right;

        }
    }

    public bool CanAttack
    {
        get
        {
            return shootCooldown <= 0f;
        }
    }
}
