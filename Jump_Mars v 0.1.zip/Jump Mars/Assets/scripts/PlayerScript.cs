﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

    public Vector2 speed = new Vector2(50, 50);

    private Vector2 movement;
    public float jumpForce;
    bool grounded = false;
    public int compteur = 0; //Temps pendant lequel la boxCollider est inactive
    public bool verif;

    public bool direction = true;

    float inputX;
    private Rigidbody2D rigidbodyComponent;

    void Update()
    {
        inputX = Input.GetAxis("Horizontal");

       if(Input.GetKeyDown(KeyCode.D) && !direction)
        {
            transform.rotation *= Quaternion.AngleAxis(180, transform.up);
            direction = true;
        }
        if(Input.GetKeyDown(KeyCode.Q) && direction)
        {
            transform.rotation *= Quaternion.AngleAxis(180, transform.up);
            direction = false;
        }

        if (grounded && Input.GetKeyDown(KeyCode.Space) && Mathf.Abs(GetComponent<Rigidbody2D>().velocity.y) < 0.01f)
        {
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);
            grounded = false;
        }
        
        if (Input.GetButton("Fire1"))
        {
            WeaponScript weapon = GetComponent<WeaponScript>();
            weapon.Attack();
        }

        if (compteur > 1) compteur--;
        if (compteur == 1)
        {
            GetComponent<Collider2D>().enabled = true;
            verif = GetComponent<Collider2D>().enabled;
            compteur = 0;
        }
    }

    void FixedUpdate()
    {
        if (rigidbodyComponent == null) rigidbodyComponent = GetComponent<Rigidbody2D>();

        movement = new Vector2(inputX * speed.x, rigidbodyComponent.velocity.y);
        rigidbodyComponent.velocity = movement;

       
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Platform"))
            grounded = true;
        if(collision.gameObject.CompareTag("Ennemi"))
        {
            GetComponent<Collider2D>().enabled = false;
            verif = GetComponent<Collider2D>().enabled;
            compteur = 40;
        }
    }
}
